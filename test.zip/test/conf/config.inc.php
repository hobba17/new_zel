<?php
defined('my-tpl') or die('Доступ запрещён!');
$config = [
	'host'	=> 'localhost',
	'admin'	=> 'admin',
	'pass'	=> '12345',
	'db'	=> 'database'
];
