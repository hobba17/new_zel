<?php
defined('my-tpl') or die('Доступ запрещён!');
class procTpl {
	function funcForeach($arr, $cod){
		foreach ($arr as $k => $v) $cod = str_replace($k, $v, $cod);
		return $cod;
	}
	function _tpl($name, $arr = false){
		$cod = file_get_contents("tpl/$name.tpl");
		if ($arr) $cod = $this->funcForeach($arr, $cod);
		return $cod;
	}
	function tplTopCode(){
		$top_code = $this->_tpl('top_code');
		$meta_str = parse_ini_file("conf/meta_str.ini");
		$top_code = str_replace('{title}', $meta_str['title'], $top_code);
		$top_code = str_replace('{descr}', $meta_str['descr'], $top_code);
		echo str_replace('{keyw}', $meta_str['keyw'], $top_code);
	}
	function tpl($name, $arr = false){
		$cod = $this->_tpl($name);
		if ($arr) $cod = $this->funcForeach($arr, $cod);
		echo $cod;
	}
}
