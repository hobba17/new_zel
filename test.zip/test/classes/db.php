<?php
defined('my-tpl') or die('Доступ запрещён!');
class DateBase {
	private $elem = '{?}';
	private $row_assoc = array();
	private $mysqli;
	function __construct() {
		global $config;
		$this->mysqli = new mysqli($config['host'], $config['admin'], $config['pass'], $config['db']);
		if ($this->mysqli->connect_errno) {
			printf("Связи с базой нет: %s\n", $this->mysqli->connect_error);
			exit;
		}
		$this->mysqli->set_charset("utf8");
		$this->mysqli->query("SET NAMES UTF8");
	}
	function metClear($zap, $par = false) {
		if ($par) {
			for ($i = 0; $i < count($par); $i++) {
				$pos = strpos($zap, $this->elem);
				$par[$i] = strip_tags($par[$i]);
				$par[$i] = $this->mysqli->real_escape_string($par[$i]);
				$arg = "'".trim($par[$i])."'";
				$zap = substr_replace($zap, $arg, $pos, strlen($this->elem));
			}
		}
		return $zap;
	}
	function selectDb($zap, $par = false) {
		$res = $this->mysqli->query($this->metClear($zap, $par));
		while ($row = $res->fetch_assoc()){
			$row_assoc[] = $row;
		}
		if (empty($row_assoc)) return 0; else return $row_assoc;
	}
	function insertDb($zap, $par = false) {
		$res = $this->mysqli->query($this->metClear($zap, $par));
		return ($res)?true:false;
	}
	function __destruct() {
		if ($this->mysqli) $this->mysqli->close();
	}
}
