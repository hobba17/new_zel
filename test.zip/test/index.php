<?php
define('my-tpl', true);
include_once './include/core.php';
if (isset($_POST['comment'])) {
	$db->insertDb("INSERT INTO `comments` (`id_hod`, `comment`, `date_comment`, `name`)
		VALUES (NULL, {?}, '".date('Y-m-d H:i')."', {?})", [$_POST['comment'],$_POST['name']]);
}
$tpl->tplTopCode();
if (($res = $db->selectDb("SELECT `id_hod`, `name`, `comment`, `date_comment` FROM `comments` ORDER BY `id_hod` DESC")) > 0) {
	$tpl->tpl('forum_do');
	foreach ($res as $row) {
		$tpl->tpl('forum', ['{name}' => $row['name'],'{date_comment}' => $row['date_comment'],'{comment}' => $row['comment']]);
	}
}
$tpl->tpl('forum_posle');
$tpl->tpl('end_code');
