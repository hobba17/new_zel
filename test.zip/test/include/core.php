<?php
defined('my-tpl') or die('Доступ запрещён!');
include_once './classes/db.php';
include_once './classes/tpl.php';
include_once './conf/config.inc.php';
$db = new DateBase;
$tpl = new procTpl;
